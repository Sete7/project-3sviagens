<div class="main-contato container">
    <div class="content contato">
        <div class="row">
            <div class="column column-6">
                <h1 class="title-contato">Contato</h1>
                <?php
                    require './mailer/form-contato.php';
                ?>
            </div>
            
            <div class="column column-6">
                <div class="contato-info">
                    <p>QNM 34 ÁREA ESPECIAL 1, SALA 511 - JK SHOPPING CEP: 72145-450</p>
                    <p>Telefones para pacotes e fretes: (61) 3336-7914 | 3336-5639 | 9601-8697 | 99601-8697 | 98117-0210</p>
                </div>

                <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15355.569041400724!2d-48.0937516!3d-15.809634!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xc44eda07a6e73937!2sJK+Shopping!5e0!3m2!1spt-BR!2sbr!4v1527264579694" width="100%" height="250" frameborder="0" style="border:0" allowfullscreen></iframe>
            </div>
        </div>
    </div>
</div>